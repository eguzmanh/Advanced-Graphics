package a2;

public class Pyramid extends WorldObject {

    private float rotationAmnt;

    // vertices of a pyramid (retrieved from source)
    private float[] vertices = {	
        -1.0f, -1.0f, 1.0f, 1.0f, -1.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //front
        1.0f, -1.0f, 1.0f, 1.0f, -1.0f, -1.0f, 0.0f, 1.0f, 0.0f,   //right
        1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 0.0f, 1.0f, 0.0f, //back
        -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f, 0.0f, 1.0f, 0.0f, //left
        -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, //LF
        1.0f, -1.0f, 1.0f, -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, -1.0f  //RR
	};
    
    /* Brick texture coordinates fo the Pyramid */
    private float[] brickTextureCoordinates = {	
        0.0f, 0.0f, 1.0f, 0.0f, 0.5f, 1.0f,
        0.0f, 0.0f, 1.0f, 0.0f, 0.5f, 1.0f,
        0.0f, 0.0f, 1.0f, 0.0f, 0.5f, 1.0f,
        0.0f, 0.0f, 1.0f, 0.0f, 0.5f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
        1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f
	};

    /* Ice texture coordinates fo the Pyramid */
    private float[] iceTextureCoordinates = {	
        0.0f, 0.0f, 0.25f, 0.25f, 0.5f, 0.0f,
        0.0f, 0.0f, 0.25f, 0.25f, 0.5f, 0.0f,
        0.0f, 0.0f, 0.25f, 0.25f, 0.5f, 0.0f,
        0.0f, 0.0f, 0.25f, 0.25f, 0.5f, 0.0f,
        0.0f, 0.0f, 0.25f, 0.25f, 0.5f, 0.0f,
        0.0f, 0.0f, 0.25f, 0.25f, 0.5f, 0.0f,
	};
	
	
     /* Defines a World Object with specific texture coordinates */
     public Pyramid(String shapeType) {
        super(shapeType);
        setVertices(vertices);
        setTextureCoordinates(brickTextureCoordinates);
        setNumVertices(18);
        setLocation(0f, 0f, 8f);
        rotationAmnt = 0.0f;
    }

    public void action() {}
    
    public void updateAction(float speed) {
        rotationAmnt += (float)speed % 360;
    }

    public float getRotAmnt() {
        return rotationAmnt;
    }
    
    public float[] getBrickTexCoords() {
        return brickTextureCoordinates;
    }
    public float[] getIceTexCoords() {
        return iceTextureCoordinates;
    }
}
