package a2;

import java.io.*;
import java.lang.Math;
import java.nio.*;
import javax.swing.*;
import static com.jogamp.opengl.GL4.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.GLContext;
import com.jogamp.opengl.util.*;

import com.jogamp.opengl.util.texture.*;
import com.jogamp.common.nio.Buffers;
import org.joml.*;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

public class Code extends JFrame implements GLEventListener, KeyListener {	
	private GLCanvas myCanvas;
	private Camera camera;

	private int renderingProgram, axisLineProgram;
	private int vao[] = new int[1];
	private int vbo[] = new int[13];
	private int mvLoc, pLoc;
	private int brickTexture, iceTexture, dolTexture, artsyTexture, floralSheetTexture, drawerDoorTexture;
	// private int numDolVertices;

	private double lastFrameTime, currFrameTime, elapsedTime, speed;

	private float aspect;
	private float tx = 0.0f, ty = 0.0f, tz = 0.0f;
	
	private boolean displayAxisLines;
	// allocate variables for display() function
	private FloatBuffer vals = Buffers.newDirectFloatBuffer(16);
	private Matrix4f pMat;  // perspective matrix
	private Matrix4f vMat;  // view matrix
	private Matrix4f mMat;  // model matrix
	private Matrix4f mvMat; // model-view matrix
	// private Matrix4fStack mvStack;

	private Pyramid pyr1;
	private Pyramid pyr2;
	private Cube cube1;
	private Cube cube2;
	private Dolphin dol;
	private Trapezium myTrapezium;
	private ManualFoodStation myFoodStation;

	// private ImportedModel dolphin;

	public Code() {	
		initTimeFrames();
		styleJFrame();
		initMainComponents();
		initMatrices();
		initCanvas();
		
		this.add(myCanvas);
		this.setVisible(true);

		Animator animator = new Animator(myCanvas);
		animator.start();
	}

	/** Inits the necessary components to run the java and shader programs */
	public void init(GLAutoDrawable drawable) {	
		GL4 gl = (GL4) GLContext.getCurrentGL();
		displayAxisLines = true;

		renderingProgram = Utils.createShaderProgram("assets/shaders/vertShader.glsl", "assets/shaders/fragShader.glsl");
		axisLineProgram = Utils.createShaderProgram("assets/shaders/lineVert.glsl", "assets/shaders/lineFrag.glsl");
		
		setPerspective();
		loadObjects();
		loadTextures();
		buildObjects();
		
		gl.glGenVertexArrays(vao.length, vao, 0);
		gl.glBindVertexArray(vao[0]);
		gl.glGenBuffers(vbo.length, vbo, 0);
		
		bindObjects(gl);
	}

	private void styleJFrame() {
		setTitle("CSC 155 - LAB 2");
		setSize(800, 800);
	}

	private void initMainComponents() {
		camera = new Camera();
	}

	private void initMatrices() {
		// Matrices for the model view stack
		pMat = new Matrix4f(); 
		vMat = new Matrix4f();  
		mMat = new Matrix4f();  
		mvMat = new Matrix4f();
		// mvStack = new Matrix4fStack(7);
	}

	private void initCanvas() {
		myCanvas = new GLCanvas();
		myCanvas.addGLEventListener(this);
		myCanvas.addKeyListener(this);
	}

	private void initTimeFrames() {
		lastFrameTime = System.currentTimeMillis();
		currFrameTime = System.currentTimeMillis();
		elapsedTime = 0.0;
	}
	
	private void setPerspective() {
		aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
		pMat.setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);
	}

	private void loadObjects() {}

	// refer to readme for source explanations
	private void loadTextures() {
		brickTexture = Utils.loadTexture("assets/textures/brick1.jpg");
		iceTexture = Utils.loadTexture("assets/textures/ice.jpg");
		dolTexture =  Utils.loadTexture("assets/textures/Dolphin_HighPolyUV.png");
		artsyTexture = Utils.loadTexture("assets/textures/pexels-anni-roenkae.jpg");
		floralSheetTexture = Utils.loadTexture("assets/textures/floral_sheet.png");
		drawerDoorTexture = Utils.loadTexture("assets/textures/Drawer_Door.jpg");
	}

	private void buildObjects() {	
		pyr1 = new Pyramid("pyramid");
		pyr2 = new Pyramid("pyramid");
		cube1 = new Cube("cube", (float)speed);
		cube2 = new Cube("cube", (float)speed);
		dol = new Dolphin("dolphin");
		myTrapezium = new Trapezium("polygon");
		myFoodStation = new ManualFoodStation("rectangle");
	}

	private void bindObjects(GL4 gl) {
		//  * pyr1 
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		FloatBuffer pyr1Buf = Buffers.newDirectFloatBuffer(pyr1.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, pyr1Buf.limit()*4, pyr1Buf, GL_STATIC_DRAW);
		
		//  pyr1 texture 
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		FloatBuffer tex1Buf = Buffers.newDirectFloatBuffer(pyr1.getBrickTexCoords());
		gl.glBufferData(GL_ARRAY_BUFFER, tex1Buf.limit()*4, tex1Buf, GL_STATIC_DRAW);

		//  * pyr2
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		FloatBuffer pyr2Buf = Buffers.newDirectFloatBuffer(pyr2.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, pyr2Buf.limit()*4, pyr2Buf, GL_STATIC_DRAW);
		
		//  pyr1 texture 
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		FloatBuffer tex2Buf = Buffers.newDirectFloatBuffer(pyr2.getIceTexCoords());
		gl.glBufferData(GL_ARRAY_BUFFER, tex2Buf.limit()*4, tex2Buf, GL_STATIC_DRAW);
			
		// * cube1
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		FloatBuffer cube1Buf = Buffers.newDirectFloatBuffer(cube1.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, cube1Buf.limit()*4, cube1Buf, GL_STATIC_DRAW);
		
		// * cube2
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		FloatBuffer cube2Buf = Buffers.newDirectFloatBuffer(cube2.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, cube2Buf.limit()*4, cube2Buf, GL_STATIC_DRAW);


		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		FloatBuffer dolBuf = Buffers.newDirectFloatBuffer(dol.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, dolBuf.limit()*4, dolBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		FloatBuffer dolTexBuf = Buffers.newDirectFloatBuffer(dol.getTextureCoordinates());
		gl.glBufferData(GL_ARRAY_BUFFER, dolTexBuf.limit()*4, dolTexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		FloatBuffer cube1TexBuf = Buffers.newDirectFloatBuffer(cube1.getArtsyTextureCoordinates());
		gl.glBufferData(GL_ARRAY_BUFFER, cube1TexBuf.limit()*4, cube1TexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		FloatBuffer cube2TexBuf = Buffers.newDirectFloatBuffer(cube2.getArtsyTextureCoordinates());
		gl.glBufferData(GL_ARRAY_BUFFER, cube2TexBuf.limit()*4, cube2TexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		FloatBuffer myTrapeziumBuf = Buffers.newDirectFloatBuffer(myTrapezium.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, myTrapeziumBuf.limit()*4, myTrapeziumBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		FloatBuffer foodStationBuf = Buffers.newDirectFloatBuffer(myFoodStation.getVertices());
		gl.glBufferData(GL_ARRAY_BUFFER, foodStationBuf.limit()*4, foodStationBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		FloatBuffer foodStationTexBuf = Buffers.newDirectFloatBuffer(myFoodStation.getTextureCoordinates());
		gl.glBufferData(GL_ARRAY_BUFFER, foodStationTexBuf.limit()*4, foodStationTexBuf, GL_STATIC_DRAW);

	}


	/** Multiply the View and Model matrices to the Model-View identity matrix */
	private void updateModelViewMatrix() {
		mvMat.identity();
		mvMat.mul(vMat);
		mvMat.mul(mMat);
	}

	/** Renders on every frame and does actions */
	public void display(GLAutoDrawable drawable) {
		GL4 gl = (GL4) GLContext.getCurrentGL();

		gl.glClear(GL_COLOR_BUFFER_BIT);
		gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		
		gl.glUseProgram(renderingProgram);
		
		upateElapsedTimeInfo();
		float speedf = (float)speed;

		// System.out.println("elapsed time: " + elapsedTime);
		pyr1.updateAction(speedf); // pyramid
		pyr2.updateAction(speedf); // pyramid
		cube1.updateAction(speedf); // cube
		// cube1.updateTranslationOffset(speedf);    // 
		cube2.updateAction(speedf); // cube
		// cube2.updateTranslationOffset(speedf);
		dol.adjustZOffset(speedf);			 // dol

		mvLoc = gl.glGetUniformLocation(renderingProgram, "mv_matrix");
		pLoc = gl.glGetUniformLocation(renderingProgram, "p_matrix");

		aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
		pMat.setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 400.0f);

		// * View Matrix from Camera
		vMat = camera.getViewMatrix();


		// * Object 1
		Vector3f pyr1Location = pyr1.getLocation();
		mMat.translation(pyr1Location.x()-2.5f, pyr1Location.y(), pyr1Location.z());
		mMat.rotate(pyr1.getRotAmnt(), 0.0f, 1.0f, 0.0f);
		// mMat.rotateXYZ(-0.45f, 0.61f, 0.0f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, brickTexture);

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, 18);


		// * Object 2
		Vector3f pyr2Location = pyr2.getLocation();
		mMat.translation(pyr2Location.x()+2.5f, pyr2Location.y(), pyr2Location.z());
		mMat.rotate(pyr2.getRotAmnt(), 0.0f, -1.0f, 0.0f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0); 
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, iceTexture);
		
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, 18); 


		// * Object 3
		Vector3f cube1Loc = cube1.getLocation();
		mMat.translation(cube1Loc.x()+1f, cube1Loc.y() + cube1.getTranslationOffset(), cube1Loc.z());	
		mMat.rotate(cube1.getRotAmnt(), 0.0f, 1.0f, 0.0f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, artsyTexture);
		
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, 36);


		// * Object 4
		Vector3f cube2Loc = cube2.getLocation();
		mMat.translation(-cube2Loc.x()-1f, cube2Loc.y() + cube2.getTranslationOffset(), cube2Loc.z());
		// mMat.rotate(cube1.getRotAmnt()*speedf, 0.0f, -1.0f, 0.0f);
		mMat.scale(0.75f, 0.75f, 0.75f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, floralSheetTexture);	


		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		
		gl.glDrawArrays(GL_TRIANGLES, 0, 36);

		// * Object 5 (dolphin)
		Vector3f dolLoc = dol.getLocation();
		mMat.translation(dolLoc.x(), dolLoc.y(), dolLoc.z() + dol.getZOffset());
		if (dol.getZDirection() < 0) mMat.rotate(135, 0.0f, 1.0f, 0.0f);
		
		mMat.scale(1.5f, 1.5f, 1.5f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, dolTexture);	

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, dol.getNumVertices());


		// * Custom Object 1
		Vector3f myTrapeziumLocation = myTrapezium.getLocation();
		mMat.translation(myTrapeziumLocation.x(), myTrapeziumLocation.y(), myTrapeziumLocation.z());
		mMat.rotate(120, 0.0f, 1.0f, 0.0f);
		// mMat.rotateXYZ(-0.45f, 0.61f, 0.0f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, floralSheetTexture);	

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0,myTrapezium.getNumVertices());

		// * Custom Object 2
		Vector3f myFoodStationLocation = myFoodStation.getLocation();
		mMat.translation(myFoodStationLocation.x(), myFoodStationLocation.y(), myFoodStationLocation.z());
		mMat.rotate(90, 0.0f, 1.0f, 0.0f);
		// mMat.rotateXYZ(-0.45f, 0.61f, 0.0f);

		updateModelViewMatrix();

		gl.glUniformMatrix4fv(mvLoc, 1, false, mvMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, drawerDoorTexture);	

		//  Just add to any texture parameter!
		// * Tiling clamp to border
		
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
		float[] niceBlueColor =  new float[]{ 0.52f, 0.86f, 1.39f, 1.0f };
		gl.glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, niceBlueColor, 0);

		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0,myTrapezium.getNumVertices());


		// * Generate the axis line with a hard coded vertex file
		if (displayAxisLines) {
			gl.glUseProgram(axisLineProgram);

			// pass in view as mvLoc to display the lines at the origin
			gl.glUniformMatrix4fv(mvLoc, 1, false, vMat.get(vals));
			gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
			gl.glDrawArrays(GL_LINES, 0, 6);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {	
		int evtKeyCode = e.getKeyCode();
		switch (evtKeyCode) {
			case KeyEvent.VK_ESCAPE:
				System.out.println("Esc key pressed");
				shutdownAction();
				break;
			case KeyEvent.VK_SPACE:
				System.out.println("Space key pressed");
				toggleAxisLinesAction();
				break;
			case KeyEvent.VK_W:
				System.out.println("W key pressed");
				fwdBwdAction((float)speed);
				break;
			case KeyEvent.VK_S:
				System.out.println("S key pressed");
				fwdBwdAction(-(float)speed);	
				break;
			case KeyEvent.VK_A:
				System.out.println("A key pressed");
				strifeAction(-(float)speed);
				break;
			case KeyEvent.VK_D:
				System.out.println("D key pressed");
				strifeAction((float)speed);
				break;
			case KeyEvent.VK_E:
				System.out.println("E key pressed");
				upDownAction(-(float)speed);
				break;
			case KeyEvent.VK_Q:
				System.out.println("Q key pressed");
				upDownAction((float)speed);
				break;
			case KeyEvent.VK_LEFT:
				System.out.println("Arrow left key pressed");
				panAction((float)speed);
				break;
			case KeyEvent.VK_RIGHT:
				System.out.println("Arrow right key pressed");
				panAction(-(float)speed);
				break;
			case KeyEvent.VK_UP:
				System.out.println("Arrow up key pressed");
				pitchAction((float)speed);
				break;
			case KeyEvent.VK_DOWN:
				System.out.println("Arrow down key pressed");
				pitchAction(-(float)speed);
				break;
			default:
				System.out.println("No command found.");
		}
	}

	/** override if desired. */
	@Override
	public void keyReleased(KeyEvent e) {}

	/** override if desired. */
	@Override
	public void keyTyped(KeyEvent e) {}

	// ? new actions!!
	private void shutdownAction() {
		System.out.println("Shutting down.");
		System.exit(0);
	}

	// **************** START Key Listener Actions ****************************

	/** toggle the VISIBILITY of the axis lines */
	public void toggleAxisLinesAction() {
		displayAxisLines = displayAxisLines ? false : true;
	}
	
	/** Move the camera forward and backward */
	public void fwdBwdAction(float newSpeed){
		Vector3f oldPosition, fwdDirection, newLocation;
		oldPosition = camera.getLocation(); 
		fwdDirection = camera.getN(); // N vector 
		fwdDirection.mul(newSpeed*3f);
		newLocation = oldPosition.add(fwdDirection.x(), fwdDirection.y(), fwdDirection.z()); 
		camera.setLocation(newLocation); 
	}

	/** Move the camera parallel to the V vetor up in positive and negative values (scale V vector */
	public void upDownAction(float newSpeed) {
		Vector3f oldPosition, upDirection, newLocation;
		
		oldPosition = camera.getLocation(); 
		upDirection = camera.getV(); // V vector 
		
		upDirection.mul(newSpeed);
		
		newLocation = oldPosition.add(upDirection.x(), upDirection.y(), upDirection.z()); 
		
		camera.setLocation(newLocation); 
	}

	/** Strife the camera (scale the U vector)  */
	public void strifeAction(float newSpeed){
		Vector3f oldPosition, rightDirection, newLocation;
		
		oldPosition = camera.getLocation(); 
		rightDirection = camera.getU(); // U vector 
		
		rightDirection.mul(newSpeed);

		newLocation = oldPosition.add(rightDirection.x(), rightDirection.y(), rightDirection.z()); 
		
		camera.setLocation(newLocation); 
	}

	/** pan the camera (routate about the Y axis) */
	public void panAction(float newSpeed) {
		Vector3f cameraLocation = camera.getLocation(); 
		Vector3f cameraU = camera.getU(); 
		Vector3f cameraV = camera.getV(); 
		Vector3f cameraN = camera.getN(); 
		
		cameraU.rotateAxis(newSpeed, cameraV.x(), cameraV.y(), cameraV.z()); 
		cameraN.rotateAxis(newSpeed, cameraV.x(), cameraV.y(), cameraV.z()); 
		
		camera.setU(cameraU);
		camera.setN(cameraN);
	}

	/** Pitch the camera up down (rotate about the U Vector) */ 
	public void pitchAction(float newSpeed) {
		Vector3f cameraLocation = camera.getLocation(); 
		Vector3f cameraU = camera.getU(); 
		Vector3f cameraV = camera.getV(); 
		Vector3f cameraN = camera.getN(); 
		
		cameraV.rotateAxis(newSpeed, cameraU.x(), cameraU.y(), cameraU.z()); 
		cameraN.rotateAxis(newSpeed, cameraU.x(), cameraU.y(), cameraU.z()); 
		
		camera.setV(cameraV);
		camera.setN(cameraN);
	}
	// **************** END Key Listener Actions ****************************
	
	// Deals with elapsed time and ensure that the values stay close
	private void upateElapsedTimeInfo() {
		lastFrameTime = currFrameTime;
		currFrameTime = System.currentTimeMillis();

		// if (currFrameTime - lastFrameTime > 15.0) { elapsedTime %= 15.0; }
		// else { elapsedTime = (currFrameTime - lastFrameTime); }


		if (currFrameTime - lastFrameTime > 100.0) { elapsedTime %= 15.0; }
		else { elapsedTime = (currFrameTime - lastFrameTime); }
		
		elapsedTime = (currFrameTime - lastFrameTime);
		speed = (float)elapsedTime / 500f;
	}

	public static void main(String[] args) { new Code(); }
	public void dispose(GLAutoDrawable drawable) {}
	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {}
}