package a2;

import org.joml.*;


/** Object class to assign common data, like speed and location to objects appearing in the 3D Scene */
public abstract class WorldObject {
    // private String name;
    private String shape;
    private Vector3f location;
    private int numVertices;
    private float[] vertices, textureCoordinates; 

    private float rotationAngle, translationOffset, yOff, xOff, zOff;
    
    /* Defines a World Object without specific texture coordinates */
    public WorldObject(String shapeType) {
        shape = shapeType;
        // rotationAngle = 0;
        // translationOffset = 0;
        // yOff = 0;
        // xOff = 0;
        // zOff = 0;
    }


    /** Stores the shape type (can be assigned to any value dev would like for their identifiers) */
    public String getShapeType() { return shape; }

    /** Gets the vec3 location of the object */
    public Vector3f getLocation() { return location; }

    /** Gets the object vertices when they are set */
    public float[] getVertices() { return vertices; }

    /** Gets the object texture coordinates when they are set */
    public float[] getTextureCoordinates() { return textureCoordinates; }

    /** get the number of vertices
     *  This function is usually called only by models that implemenet indices
     * @return numVertices
     */
    public int getNumVertices() { return numVertices; }

    // public float getRotationAngle() { return rotationAngle; }
    // public float getTranslationOffset() { return translationOffset; }

    /** If floats are passed in, send a vector to the real setLocation() */
    public void setLocation(float x, float y, float z) { setLocation(new Vector3f(x,y,z)); }

    /** Sets the location of the object in the 3D scene */
    public void setLocation(Vector3f newLocation) { location = new Vector3f(newLocation); }

    /** Sets the vertices of the object */
    public void setVertices(float[] newVertices) { vertices = newVertices; }

    /** Sets the texture coordinates assigned to the object */
    public void setTextureCoordinates(float[] newTextureCoordinates) { textureCoordinates = newTextureCoordinates; }

    /** set the number of vertices 
     * use this function when doing index-based models
    */
    public void setNumVertices(int numV) { numVertices = numV; }
    // public void setRotationAngle(float newR) { rotationAngle = newR; }
    // public void setTranslationOffset(float newT) { translationOffset = newT; }

    /** Curerrently doesn't do anything and can be overwritten
     * The idea behind teh function is that at one point we can call it and it will execute an action the object defines
     */
    public abstract void action();
}
