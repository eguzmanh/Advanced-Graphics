package a2;
import org.joml.*;

// ! CSC165 TAGE engine contains a camer and was used as referenced. 
// !Code from the file was used

/** Class to interact with the 3D scene/world by virtualizing the view,
 * Contains UVN vectors and a location vector
 * 
 */
public class Camera {
    private Vector3f location;
    private Vector3f u, v, n;
    private Matrix4f viewMatrix, viewRotationMatrix, viewTranslationMatrix;
    
    public Camera() {	
		location = new Vector3f(0.0f, 1.5f, 15f);
		u = new Vector3f(1.0f, 0.0f, 0.0f);
		v = new Vector3f(0.0f, 1.0f, 0.0f);
		n = new Vector3f(0.0f, 0.0f, -1.0f);
        viewMatrix = new Matrix4f();
        viewRotationMatrix = new Matrix4f();
        viewTranslationMatrix = new Matrix4f();
	}

    /** sets the world location of this Camera */
	public void setLocation(Vector3f l) { location.set(l); }

	/** sets the U (right-facing) vector for this Camera */
	public void setU(Vector3f newU) { u.set(newU); }

	/** sets the V (upward-facing) vector for this Camera */
	public void setV(Vector3f newV) { v.set(newV); }

	/** sets the N (forward-facing) vector for this Camera */
	public void setN(Vector3f newN) { n.set(newN); }

	/** returns the world location of this Camera */
	public Vector3f getLocation() { return new Vector3f(location); }

	/** gets the U (right-facing) vector for this Camera */
	public Vector3f getU() { return new Vector3f(u); }

	/** gets the V (upward-facing) vector for this Camera */
	public Vector3f getV() { return new Vector3f(v); }

	/** gets the N (forward-facing) vector for this Camera */
	public Vector3f getN() { return new Vector3f(n); }

	/** Build the View Matrix to render objects in the frustum */
    protected Matrix4f getViewMatrix() { 
        viewTranslationMatrix.set(1.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 1.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, 0.0f,
		-location.x(), -location.y(), -location.z(), 1.0f);

		viewRotationMatrix.set(u.x(), v.x(), -n.x(), 0.0f,
		u.y(), v.y(), -n.y(), 0.0f,
		u.z(), v.z(), -n.z(), 0.0f,
		0.0f, 0.0f, 0.0f, 1.0f);

		viewMatrix.identity();
		viewMatrix.mul(viewRotationMatrix);
		viewMatrix.mul(viewTranslationMatrix);

		return viewMatrix;
    }
}
