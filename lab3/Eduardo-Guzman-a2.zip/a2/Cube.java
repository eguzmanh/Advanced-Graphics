package a2;

import org.joml.*;
import org.joml.Math;


public class Cube extends WorldObject {

    // private Vector3f rotV;
    private Vector3f rotationV;;
    private Vector3f translationV;
    
    private float rotationAngle;
    private float translationAmnt;
    private float offsetDir;

    private float[] vertices = {	
        -1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, -1.0f,
        1.0f, -1.0f, -1.0f, 1.0f,  1.0f, -1.0f, -1.0f,  1.0f, -1.0f,
        1.0f, -1.0f, -1.0f, 1.0f, -1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
        1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
        1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f, -1.0f,  1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f, -1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f, -1.0f,
        1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,
        -1.0f,  1.0f, -1.0f, 1.0f,  1.0f, -1.0f, 1.0f,  1.0f,  1.0f,
        1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f, -1.0f
    };

    // custom texture coordinates used for the cube with the artsy texture image
    private float[] artsyTextureCoordinates = {	
        0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f,
    };

     /* Defines a World Object with specific texture coordinates */
     public Cube(String shapeType, float speed) {
        super(shapeType);
        setVertices(vertices);
        setNumVertices(36);
        setLocation(3f, 0f, 3.0f);
        rotationAngle = 0;
    }

    @Override
    public void action() {}


    /** Currently will update the object rotation angle and translation offsets with elapsed data */
    public void updateAction(float speed) {
        // updateRotationAngle(speed*.01f % 360);
        updateTranslationOffset(speed);
    }

    /** Updates the rotation angle only */
    public void updateRotationAngle(float newAngle) {
        rotationAngle += newAngle;
    }

    /** Get the rotation angle */
    public float getRotAmnt() {
        return rotationAngle;
    }

    /** Updates the Translation Offset only  */
    public void updateTranslationOffset(float speed) {
        if(translationAmnt >= 5.0) { offsetDir =  -1.0f; }
        if(translationAmnt <=  0.0f) { offsetDir = 1.0f; }

            translationAmnt += offsetDir * speed;
    }

    /** Get the translation offset */
    public float getTranslationOffset() {
        return translationAmnt;
    }
    
    /** Used by cubes to retrieve the texture coordinates chosen for the arsty image */
    public float[] getArtsyTextureCoordinates() {
        return artsyTextureCoordinates;
    }
}