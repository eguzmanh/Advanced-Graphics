package a2;

import com.jogamp.opengl.util.texture.*;
import org.joml.*;


// World object that is loaded from an OBJ file and also uses a special texture file
public class Dolphin extends WorldObject {
    private int numDolVertices;
    private ImportedModel dolphin;

	private float zOff, zDir;



    public Dolphin(String shapeType) {
        super(shapeType);
        dolphin = new ImportedModel("assets/models/dolphinHighPoly.obj");
        setupVertices();
        setLocation(0f, 0f, 10f);

		zOff = 0.01f;
		zDir = 1.0f;
    }

    private void setupVertices()
	{	
        // GL4 gl = (GL4) GLContext.getCurrentGL();
	
		numDolVertices = dolphin.getNumVertices();  
		Vector3f[] tempVertices = dolphin.getVertices();
		Vector2f[] tempTexCoords = dolphin.getTexCoords();
		// Vector3f[] normals = myModel.getNormals();
		
		float[] pvalues = new float[numDolVertices*3];
		float[] tvalues = new float[numDolVertices*2];
        
		// float[] nvalues = new float[numObjVertices*3];
		
		for (int i=0; i<numDolVertices; i++)
		{	pvalues[i*3]   = (float) (tempVertices[i]).x();
			pvalues[i*3+1] = (float) (tempVertices[i]).y();
			pvalues[i*3+2] = (float) (tempVertices[i]).z();
			tvalues[i*2]   = (float) (tempTexCoords[i]).x();
			tvalues[i*2+1] = (float) (tempTexCoords[i]).y();
		}
        setVertices(pvalues);
        setTextureCoordinates(tvalues);
	}

	/** Dolphin's are created with index based arrays, so this function will call the accurate vertices */
    public int getNumVertices() {
        return numDolVertices;
    }

	/** adjusts the zOffset for the dophin */
	public void adjustZOffset(float speed) {
		// zOff += 0.01f;
		// if (zOff > 1f) {
		// 	zOff *= -1;
		// }

		// setLocation()
		if (zOff >= 0f) zDir = -speed;
		if (zOff <= -7f) zDir = speed;

		zOff += zDir;

		// System.out.println("Dolphin offset: " + zOff);
		// if (zOff < 0.25)
	}

	/** Get the z offset to move the dolphin */
	public float getZOffset() {
		return zOff;
	}

	/** Get the direction of the dolphin to ensure correct movement (range is [-1,1] ) */
	public float getZDirection() {
		return zDir;
	}

	@Override
    public void action() {}
}
